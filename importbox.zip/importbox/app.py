"""ImportBox backend: run Python, Java and C++ code and auto-install whatever the code imports."""
import ast, importlib, importlib.util, os, re, shutil, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path
from flask import Flask, jsonify, request

BASE = Path(__file__).parent
PY_DIR, JAR_DIR, INC_DIR = (BASE / "packages" / d for d in ("python", "java", "cpp"))
for d in (PY_DIR, JAR_DIR, INC_DIR):
    d.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(PY_DIR))

TIMEOUT = int(os.getenv("RUN_TIMEOUT", "20"))
app = Flask(__name__, static_folder="static", static_url_path="")

# import name -> pip name, when they differ
PIP_NAMES = {"sklearn": "scikit-learn", "cv2": "opencv-python-headless", "PIL": "pillow",
             "bs4": "beautifulsoup4", "yaml": "pyyaml", "skimage": "scikit-image",
             "dotenv": "python-dotenv", "dateutil": "python-dateutil", "Crypto": "pycryptodome",
             "attr": "attrs", "jwt": "pyjwt", "serial": "pyserial", "git": "gitpython"}

# Java package prefix -> maven coordinates (group:artifact:version)
MAVEN = {"com.google.gson": "com.google.code.gson:gson:2.11.0",
         "org.apache.commons.lang3": "org.apache.commons:commons-lang3:3.14.0",
         "org.apache.commons.math3": "org.apache.commons:commons-math3:3.6.1",
         "org.apache.commons.io": "commons-io:commons-io:2.16.1",
         "org.json": "org.json:json:20240303"}

# C++ header -> download URL (header-only libraries)
HEADERS = {"nlohmann/json.hpp": "https://raw.githubusercontent.com/nlohmann/json/v3.11.3/single_include/nlohmann/json.hpp"}
JDK_PREFIXES = ("java.", "javax.", "jdk.", "org.w3c.", "org.xml.", "org.ietf.")


def limits(memory=True):
    def fn():
        import resource
        os.setsid()
        resource.setrlimit(resource.RLIMIT_CPU, (TIMEOUT, TIMEOUT))
        resource.setrlimit(resource.RLIMIT_FSIZE, (50 << 20, 50 << 20))
        if memory:
            resource.setrlimit(resource.RLIMIT_AS, (2 << 30, 2 << 30))
    return fn if os.name == "posix" else None


def run(cmd, cwd, stdin="", env=None, memory=True, timeout=TIMEOUT):
    try:
        p = subprocess.run(cmd, cwd=cwd, input=stdin, capture_output=True, text=True, timeout=timeout,
                           env=env, preexec_fn=limits(memory))
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", f"Stopped: the program ran longer than {timeout} seconds."
    except FileNotFoundError as e:
        return 127, "", f"Tool not found: {e.filename}. Install it on the server first."


def download(url, dest):
    dest.parent.mkdir(parents=True, exist_ok=True)
    urllib.request.urlretrieve(url, dest)


# ---------- Python ----------
def python_imports(code):
    mods = set()
    for n in ast.walk(ast.parse(code)):
        if isinstance(n, ast.Import):
            mods |= {a.name.split(".")[0] for a in n.names}
        elif isinstance(n, ast.ImportFrom) and n.level == 0 and n.module:
            mods.add(n.module.split(".")[0])
    return sorted(m for m in mods if m not in sys.stdlib_module_names)


def run_python(code, stdin, tmp, log, installed):
    try:
        mods = python_imports(code)
    except SyntaxError as e:
        return 1, "", f"SyntaxError: {e.msg} (line {e.lineno})"
    for m in mods:
        importlib.invalidate_caches()
        if importlib.util.find_spec(m):
            continue
        pkg = PIP_NAMES.get(m, m)
        log.append(f"Installing {pkg} ...")
        rc, out, err = run([sys.executable, "-m", "pip", "install", "--quiet", "--target", str(PY_DIR), pkg],
                           tmp, timeout=900, memory=False)
        if rc:
            return 1, "", f"Could not install {pkg}:\n{err.strip()[-800:]}"
        installed.append(pkg)
    (tmp / "main.py").write_text(code)
    env = {**os.environ, "PYTHONPATH": str(PY_DIR), "MPLBACKEND": "Agg"}
    return run([sys.executable, "-u", "main.py"], tmp, stdin, env)


# ---------- Java ----------
def run_java(code, stdin, tmp, log, installed):
    for coord in re.findall(r"//\s*@maven\s+(\S+)", code):
        MAVEN[f"_directive_{coord}"] = coord
    wanted = {v for k, v in MAVEN.items() if k.startswith("_directive_")}
    for imp in re.findall(r"^\s*import\s+(?:static\s+)?([\w.]+)", code, re.M):
        if imp.startswith(JDK_PREFIXES):
            continue
        hit = next((v for k, v in MAVEN.items() if imp.startswith(k)), None)
        if hit:
            wanted.add(hit)
        else:
            log.append(f"No download rule for {imp}. Add '// @maven group:artifact:version' to your code.")
    for coord in wanted:
        g, a, v = coord.split(":")
        jar = JAR_DIR / f"{a}-{v}.jar"
        if not jar.exists():
            log.append(f"Downloading {coord} ...")
            try:
                download(f"https://repo1.maven.org/maven2/{g.replace('.', '/')}/{a}/{v}/{a}-{v}.jar", jar)
                installed.append(coord)
            except Exception as e:
                return 1, "", f"Could not download {coord}: {e}"
    name = (re.search(r"public\s+(?:final\s+)?class\s+(\w+)", code) or re.search(r"class\s+(\w+)", code))
    name = name.group(1) if name else "Main"
    (tmp / f"{name}.java").write_text(code)
    jars = os.pathsep.join(str(j) for j in JAR_DIR.glob("*.jar"))
    cp = os.pathsep.join([".", jars]) if jars else "."
    rc, out, err = run(["javac", "-cp", cp, f"{name}.java"], tmp, memory=False, timeout=60)
    if rc:
        return rc, out, err
    return run(["java", "-cp", cp, name], tmp, stdin, memory=False)


# ---------- C++ ----------
def run_cpp(code, stdin, tmp, log, installed):
    for inc in re.findall(r'#include\s*[<"]([^>"]+)[>"]', code):
        if inc in HEADERS and not (INC_DIR / inc).exists():
            log.append(f"Downloading {inc} ...")
            try:
                download(HEADERS[inc], INC_DIR / inc)
                installed.append(inc)
            except Exception as e:
                return 1, "", f"Could not download {inc}: {e}"
    (tmp / "main.cpp").write_text(code)
    exe = "main.exe" if os.name == "nt" else "main"
    rc, out, err = run(["g++", "-std=c++17", "-O1", "-I", str(INC_DIR), "main.cpp", "-o", exe], tmp,
                       memory=False, timeout=60)
    if rc:
        return rc, out, err
    return run([str(tmp / exe)], tmp, stdin)


RUNNERS = {"python": run_python, "java": run_java, "cpp": run_cpp}


@app.post("/api/run")
def api_run():
    data = request.get_json(silent=True) or {}
    lang, code = data.get("language"), data.get("code", "")
    if lang not in RUNNERS:
        return jsonify(ok=False, stderr="Pick Python, Java or C++."), 400
    if not code.strip() or len(code) > 100_000:
        return jsonify(ok=False, stderr="Write some code first (max 100 KB)."), 400
    log, installed, start = [], [], time.time()
    with tempfile.TemporaryDirectory() as t:
        rc, out, err = RUNNERS[lang](code, data.get("stdin", ""), Path(t), log, installed)
    return jsonify(ok=rc == 0, exit_code=rc, stdout=out[-20000:], stderr=err[-8000:],
                   log=log, installed=installed, seconds=round(time.time() - start, 2))


@app.get("/api/status")
def status():
    return jsonify(python=True, java=bool(shutil.which("javac")), cpp=bool(shutil.which("g++")))


@app.get("/")
def index():
    return app.send_static_file("index.html")


if __name__ == "__main__":
    app.run(host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "5000")))
