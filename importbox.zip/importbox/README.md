# ImportBox

Write Python, Java or C++ in the browser. Whatever you import is installed automatically, then your code runs.

## Run it
    pip install -r requirements.txt
    python app.py          # open http://127.0.0.1:5000

Needs Python 3.10+. For Java install a JDK (javac), for C++ install g++.

## Run it safely with Docker (recommended)
    docker compose up --build

## How imports work
- **Python:** imports are read from your code. Missing ones are installed with pip (sklearn becomes scikit-learn, cv2 becomes opencv, and so on). Add more names in PIP_NAMES in app.py.
- **Java:** known libraries (Gson, Commons Lang/Math/IO, org.json) download from Maven Central. For any other, add a line: `// @maven group:artifact:version`
- **C++:** the standard library works out of the box. nlohmann/json.hpp downloads automatically. Add more in HEADERS in app.py.

Installed packages are cached in the packages/ folder.

## Security
This app runs code that users send. Only expose it publicly inside Docker, with the limits in docker-compose.yml, and add a login first.
