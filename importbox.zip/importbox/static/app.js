const TEMPLATES = {
  python: ["import math", "import numpy as np", "from sklearn.linear_model import LinearRegression", "",
    "X = np.array([[1], [2], [3], [4]])", "y = np.array([2, 4, 6, 8])",
    "model = LinearRegression().fit(X, y)", "print('sqrt(16) =', math.sqrt(16))",
    "print('prediction for 5:', model.predict([[5]])[0])"].join("\n"),
  java: ["import java.util.*;", "import com.google.gson.Gson;", "", "public class Main {",
    "    public static void main(String[] args) {", "        Map<String, Object> m = new HashMap<>();",
    "        m.put(\"sqrt\", Math.sqrt(16));", "        System.out.println(new Gson().toJson(m));", "    }", "}"].join("\n"),
  cpp: ["#include <iostream>", "#include <cmath>", "#include <nlohmann/json.hpp>", "",
    "int main() {", "    nlohmann::json j;", "    j[\"sqrt\"] = std::sqrt(16);",
    "    std::cout << j.dump() << std::endl;", "}"].join("\n")
};
const MONACO = { python: "python", java: "java", cpp: "cpp" };
const $ = id => document.getElementById(id);
let lang = "python", editor = null, fallback = null;
const store = { ...TEMPLATES };

const getCode = () => editor ? editor.getValue() : fallback.value;
const setCode = v => editor ? editor.setValue(v) : (fallback.value = v);

function initEditor() {
  const host = $("editor");
  const useFallback = () => {
    fallback = document.createElement("textarea");
    fallback.spellcheck = false; fallback.value = store[lang]; host.appendChild(fallback);
  };
  if (typeof require === "undefined") return useFallback();
  require.config({ paths: { vs: "https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs" } });
  require(["vs/editor/editor.main"], () => {
    editor = monaco.editor.create(host, { value: store[lang], language: MONACO[lang], theme: "vs-dark",
      automaticLayout: true, fontSize: 14, minimap: { enabled: false } });
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter, runCode);
  }, useFallback);
}

document.querySelectorAll("#langs button").forEach(b => b.onclick = () => {
  store[lang] = getCode();
  document.querySelector("#langs .on").classList.remove("on");
  b.classList.add("on"); lang = b.dataset.lang;
  if (editor) monaco.editor.setModelLanguage(editor.getModel(), MONACO[lang]);
  setCode(store[lang]);
});

async function runCode() {
  const btn = $("run");
  btn.disabled = true; $("out").textContent = "Running..."; $("out").className = "";
  $("pkgs").textContent = "Checking imports..."; $("meta").textContent = "";
  try {
    const r = await fetch("/api/run", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ language: lang, code: getCode(), stdin: $("stdin").value }) });
    const d = await r.json();
    $("out").innerHTML = "";
    if (d.stdout) $("out").append(d.stdout);
    if (d.stderr) { const s = document.createElement("span"); s.className = "err"; s.textContent = d.stderr; $("out").append(s); }
    if (!d.stdout && !d.stderr) $("out").textContent = "Finished with no output.";
    $("pkgs").textContent = d.installed?.length ? "Installed: " + d.installed.join(", ") :
      (d.log?.length ? d.log.join("\n") : "Everything you imported was already available.");
    $("meta").textContent = d.seconds != null ? `${d.ok ? "OK" : "Failed"} in ${d.seconds}s` : "";
  } catch (e) {
    $("out").innerHTML = ""; const s = document.createElement("span"); s.className = "err";
    s.textContent = "Cannot reach the server. Start it with: python app.py"; $("out").append(s);
  }
  btn.disabled = false;
}
$("run").onclick = runCode;
document.addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") runCode(); });
initEditor();
