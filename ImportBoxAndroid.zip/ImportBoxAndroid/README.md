# ImportBox for Android

Two parts: `app/` is the Android app (Kotlin) and `backend/` is the server that runs the code.
Phones cannot run pip, javac or g++, so the app sends your code to the backend and shows the result.

## 1. Start the backend (on your computer)
    cd backend
    pip install -r requirements.txt
    HOST=0.0.0.0 python app.py        # Windows: set HOST=0.0.0.0 then python app.py

Install a JDK for Java and g++ for C++. Or run `docker compose up --build` in `backend/`.

## 2. Build the app
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Press Run to use an emulator, or Build > Build APK(s) to install on your phone.

## 3. Connect
- Emulator: the default address http://10.0.2.2:5000 works.
- Real phone: put the phone and computer on the same Wi-Fi, then type http://YOUR-COMPUTER-IP:5000 in the Server address box at the bottom of the app.
- To use it anywhere, deploy the backend to a server (VPS) and enter its address.

## Security
The backend runs code that people send. Use Docker and add a login before putting it on the internet.
