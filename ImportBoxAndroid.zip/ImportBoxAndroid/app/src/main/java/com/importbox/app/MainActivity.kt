package com.importbox.app

import android.graphics.Color
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val store = mutableMapOf(
        "python" to """
            import math
            import numpy as np
            from sklearn.linear_model import LinearRegression

            X = np.array([[1], [2], [3], [4]])
            y = np.array([2, 4, 6, 8])
            model = LinearRegression().fit(X, y)
            print("sqrt(16) =", math.sqrt(16))
            print("prediction for 5:", model.predict([[5]])[0])
        """.trimIndent(),
        "java" to """
            import java.util.*;
            import com.google.gson.Gson;

            public class Main {
                public static void main(String[] args) {
                    Map<String, Object> m = new HashMap<>();
                    m.put("sqrt", Math.sqrt(16));
                    System.out.println(new Gson().toJson(m));
                }
            }
        """.trimIndent(),
        "cpp" to """
            #include <iostream>
            #include <cmath>
            #include <nlohmann/json.hpp>

            int main() {
                nlohmann::json j;
                j["sqrt"] = std::sqrt(16);
                std::cout << j.dump() << std::endl;
            }
        """.trimIndent()
    )
    private var lang = "python"

    private lateinit var code: EditText
    private lateinit var stdin: EditText
    private lateinit var server: EditText
    private lateinit var out: TextView
    private lateinit var pkgs: TextView
    private lateinit var run: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        code = findViewById(R.id.code)
        stdin = findViewById(R.id.stdin)
        server = findViewById(R.id.server)
        out = findViewById(R.id.out)
        pkgs = findViewById(R.id.pkgs)
        run = findViewById(R.id.run)

        val prefs = getSharedPreferences("importbox", MODE_PRIVATE)
        // 10.0.2.2 reaches your computer from the Android emulator
        server.setText(prefs.getString("server", "http://10.0.2.2:5000"))
        code.setText(store["python"])

        findViewById<MaterialButtonToggleGroup>(R.id.toggle).addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            store[lang] = code.text.toString()
            lang = when (id) {
                R.id.btnJava -> "java"
                R.id.btnCpp -> "cpp"
                else -> "python"
            }
            code.setText(store[lang])
        }

        run.setOnClickListener {
            val url = server.text.toString().trim().trimEnd('/')
            prefs.edit().putString("server", url).apply()
            runCode(url)
        }
    }

    private fun runCode(baseUrl: String) {
        run.isEnabled = false
        out.text = "Running..."
        pkgs.text = "Checking imports..."
        val body = JSONObject()
            .put("language", lang)
            .put("code", code.text.toString())
            .put("stdin", stdin.text.toString())
            .toString()

        thread {
            val result = try {
                post("$baseUrl/api/run", body)
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                run.isEnabled = true
                if (result == null) {
                    showOutput("", "Cannot reach the server. Check the address below and that the backend is running.")
                    pkgs.text = ""
                    return@runOnUiThread
                }
                showOutput(result.optString("stdout"), result.optString("stderr"))
                val installed = result.optJSONArray("installed")
                val log = result.optJSONArray("log")
                pkgs.text = when {
                    installed != null && installed.length() > 0 ->
                        "Installed: " + (0 until installed.length()).joinToString(", ") { installed.getString(it) }
                    log != null && log.length() > 0 ->
                        (0 until log.length()).joinToString("\n") { log.getString(it) }
                    else -> "Everything you imported was already available."
                }
            }
        }
    }

    private fun showOutput(stdout: String, stderr: String) {
        val sb = SpannableStringBuilder(stdout)
        if (stderr.isNotEmpty()) {
            val start = sb.length
            sb.append(stderr)
            sb.setSpan(ForegroundColorSpan(Color.parseColor("#FF6B6B")), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        out.text = if (sb.isEmpty()) "Finished with no output." else sb
    }

    private fun post(url: String, body: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 10_000
        c.readTimeout = 900_000 // first pip install can take a while
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
        val stream = if (c.responseCode < 400) c.inputStream else c.errorStream
        return JSONObject(stream.bufferedReader().readText())
    }
}
